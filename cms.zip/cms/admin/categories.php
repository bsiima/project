
<?php include "includes/admin_header.php";?>



    <div id="wrapper">
        

        <!-- Navigation -->
<?php include "includes/admin_navigation.php";?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           WELCOME
                            <small>Author!</small>
                            
                        </h1>
<!------- ADD CATEGORY FORM-->
                          <div class="col-xs-6">
                              <?php
                              insert_categories();
                              ?>
                            <form action="" method="post">
                                <label for="cat_title"> Add Category</label>
                                <div class="form-group">
                                <input type="text" class="form-control" name="cat_title">
                                </div >
                                <div class="form-group">
                                <input class="btn btn-primary" type="submit" name="submit" value="submit"/>
                                    </div>
                            </form>
                        
 <!----end insert form----- >
<!-------UPDATE CATEGORY FORM-->
<?php
if(isset($_GET['edit'])){

include"includes/update.php";
}
?>
                             
                             
                           
                        </div>
 <!----end update form----- >

<!----------- TABLE-->
                        <div class="col-xs-6">
                          
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                    <td>ID</td>
                                        <td> CATEGORY</td>
                                    </tr>
                                 
                                </thead>
                                
                                <tbody>
                                     <?php
                            Display_All_Categories();      
                                     ?>
<!--delete query-->
<?php
                                    delete_category();

?>
<!-- end of delete query -->


                                </tbody>
                            
                            </table>
                        </div>
<!---------End table  ---->
                        
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->


<?php include "includes/admin_footer.php";?>

