<?php
if(isset($_POST['create_user'])){
    
                    $username =$_POST['username'];
                    $password =$_POST['password'];
                    $firstname = $_POST['firstname'];
                    $lastname = $_POST['lastname'];
                    $email = $_POST['email'];
                    $image=$_FILES['image']['name'];
                    $image_temp =$_FILES['image']['tmp_name'];
                    $role = $_POST['role'];
                  

     
    move_uploaded_file($image_temp,"../images/$image");
    
    $query = "INSERT INTO users(username,password,user_firstname,user_lastname,user_email,user_image,user_role,randSalt) ";
    
    $query .="VALUES('{$username}','{$password}','{$firstname}','{$lastname}','{$email}','{$image}','{$role}',now())";
    
    $insert_user = mysqli_query($connection,$query);
    
    confirm($insert_user);
    
    echo "User has been Created   "."<a href='users.php'>View Users Table</a>";
    

    
    
}


?>

<form action="" method="post" enctype="multipart/form-data">
    
    <div class="col-xs-12">
        <label for="username"> Username </label>
        <div class="form-group">
        <input class="form-control "name="username" type="text" value="" />
        </div>
    
    </div>
    
        
        <div class="col-xs-12">
        <label for="password">Password </label>
        <div class="form-group">
        <input class="form-control "name="password" type="text" value="" />
          </div>
    </div>
    
        <div class="col-xs-12">
        <label for="firstname"> Firstname </label>
        <div class="form-group">
        <input class="form-control "name="firstname" type="text" value="" />
        </div>
    
    </div>
    
        <div class="col-xs-12">
        <label for="lastname"> Lastname</label>
        <div class="form-group">
        <input class="form-control "name="lastname" type="text" value="" />
        </div>
    
    </div>
    
     <div class="col-xs-12">
        <label for="email"> Email</label>
        <div class="form-group">
        <input class="form-control "name="email" type="text" value="" />
        </div>
    
    </div>
    
        <div class="form-group">
        <label for="image"> Post Image </label>
        <input name="image" type="file" />
      
    </div>
    
        <div class="col-xs-12">
        <label for="role"> Role </label>
        <div class="form-group">
            <select  name="role" id="">
                <option value="subscriber">Select Role</option>
                <option value="admin">Admin</option>
                <option value="subscriber">Subscricer</option>
            
            
            </select>
        
        </div>
    
    </div>
    
    
    
        <div class="form-group">
        <input class="btn btn-primary" name="create_user" type="submit" value="Create" />
        </div>
    
  

</form>