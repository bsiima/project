<div class="col-xs-12">
<form>
<table class="table table-bordered table-hover">
    
    <div id="bulkOptionsContainer" class="col-xs-4">
        <select name="" id="">
            <option value="">Select Options</option>
            <option value="">Publish</option>
            <option value="">Draft</option>
            <option value="">Delete</option>
            
            <div  class="col-xs-4">
            
            <input class="btn btn-success" type="submit" name="submit"  value="Apply"/>
            <a href="add_posts.php" class="btn btn-primary"> Add new </a>
            </div>
        
        
        </select>
    
    </div>
    
    
        <thead class="table">
            <tr>
                <th>ID</th>
                <th>Author</th>
                <th>Title</th>
                <th>Category</th>
                <th>Status</th>
                <th>Image</th>
                <th>Content</th>
                <th>Tags</th>
                <th>Comments</th>
                <th>Date</th>
                <th>Edit</th>
                <th>Delete</th>

            </tr>

                <?php
                 
                $query = "SELECT * FROM posts";
                $select_data = mysqli_query($connection,$query);
            
                while($row= mysqli_fetch_assoc($select_data)){

                    $post_id=$row['post_id'];
                    $post_author=$row['post_author'];
                    $post_title=$row['post_title'];
                    $post_category_id=$row['post_category_id'];
                    $post_status=$row['post_status'];
                    $post_image=$row['post_image'];
                    $post_content=$row['post_content'];
                    $post_tags=$row['post_tags'];
                    $post_comment_count=$row['post_comment_count'];
                    $post_date=$row['post_date'];

                    echo "<tr>";
                    echo "<td>{$post_id}</td>";
                    echo "<td>{$post_author}</td>";
                    echo "<td>{$post_title}</td>";
                            $query = "SELECT * FROM categories WHERE Cat_id =$post_category_id";
                            $select_post_category = mysqli_query($connection,$query);
                            confirm($select_post_category);
                            while($row= mysqli_fetch_assoc($select_post_category)){

                            $cat_id=$row['Cat_id'];
                            $cat_title=$row['Cat_title'];
                            }
                    echo "<td>{$cat_title}</td>";
                    echo "<td>{$post_status}</td>";
                    echo "<td><img width='100' class='img responsive' src='../images/{$post_image}' alt='image'/></td>";
                    echo "<td>{$post_content}</td>";
                    echo "<td>{$post_tags}</td>";
                    echo "<td>{$post_comment_count}</td>";
                    echo "<td>{$post_date}</td>";
                    echo "<td> <a href='posts.php?source=edit_post&p_id={$post_id}'> Edit </a></td>";
                    echo "<td> <a href='posts.php?delete={$post_id}'> Delete </a></td>";
                    echo "<tr>";


                }

                ?>

        </thead>
    </table>
<?php
if(isset($_GET['delete'])){
$the_post_id = $_GET['delete'];
   

$query ="DELETE FROM posts WHERE post_id = {$the_post_id}";
$delete_query = mysqli_query($connection,$query);
 header("location:posts.php");   
}
?>
</form>
</div>