 <form action="" method="post">
                                <label for="cat_title">Edit Category</label>
                                 <?php
                                if(isset($_GET['edit'])){
                                    $cat_id= $_GET['edit'];
                                    
                            $query = "SELECT * FROM categories WHERE Cat_id= {$cat_id} ";
                            $select_category_query = mysqli_query($connection,$query);
                                while($row=mysqli_fetch_assoc($select_category_query)){
                                    $cat_id= $row['Cat_id'];
                                    $cat_title =$row['Cat_title'];
                                    
                                    ?>
                                
                                   <div class="form-group">
                                <input  value="<?php if(isset($cat_title)){echo $cat_title;}?>"type="text" class="form-control" name="cat_title">
                                </div >
                                
                            <?php
                                }}
                            ?>
                                <?php /////// UPDATE QUERY
                                if(isset($_POST['update_category'])){
                                  
                                  $cat_title= $_POST['cat_title'];
                                  
                                  
                                    $query = " UPDATE categories SET Cat_title ='{$cat_title}' WHERE Cat_id ={$cat_id}";
                                   $update_category = mysqli_query($connection,$query); 
                                    
                                      if(!$update_category){
                                          die("QUERY FAILED" . mysqli_error($connection));
                                      }
                             
                                  
                                  
                                  
                              }
                                
                                ?>
                                
                                <div class="form-group">
                                <input class="btn btn-primary" type="submit" name="update_category" value="Update"/>
                                    </div>
                            </form>