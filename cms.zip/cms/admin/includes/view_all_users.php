
<!-- tablr starts here                       -->
                        
<div class="col-xs-12">
<table class="table table-bordered table-hover">
        <thead class="table">
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
                <th>Firstname</th>
                <th>Lastname</th>
                <th>Email</th>
                <th>Image</th>
                <th>Role</th>
                <th>Date</th>
                <th>Edit</th>
                <th>Delete</th>

            </tr>

                <?php
                 
                $query = "SELECT * FROM users";
                $select_users = mysqli_query($connection,$query);
            
                while($row= mysqli_fetch_assoc($select_users)){

                    $user_id = $row['user_id'];
                    $username =$row['username'];
                    $password =$row['password'];
                    $user_firstname = $row['user_firstname'];
                    $user_lastname = $row['user_lastname'];
                    $user_email = $row['user_email'];
                    $user_image = $row['user_image'];
                    $user_role = $row['user_role'];
                    $date = $row['randSalt'];
                    

                    echo "<tr>";
                    echo "<td>{$user_id}</td>";
                    echo "<td>{$username}</td>";
                    echo "<td>{$password}</td>";
                    echo "<td>{$user_firstname}</td>";
                    echo "<td>{$user_lastname}</td>";
                    echo "<td>{$user_email}</td>";
                    echo "<td><img width='100' class='img responsive' src='../images/{$user_image}' alt='image'/></td>";
                    echo "<td>{$user_role}</td>";
                    echo "<td>{$date}</td>";
              
                    echo "<td> <a href='users.php?source=edit_user&p_id={$user_id}'> Edit </a></td>";
                    echo "<td> <a href='users.php?delete_user={$user_id}'> Delete </a></td>";
                     echo "<td> <a href='users.php?admin={$user_id}'>Admin </a></td>";
                     echo "<td> <a href='users.php?subscriber={$user_id}'> Subcriber </a></td>";
                    echo "<tr>";
                    


                }

                ?>

        </thead>
    </table>
<!--change role to admin -->
<?php
if(isset($_GET['admin'])){
$the_user_id = $_GET['admin'];
   

$query ="UPDATE users SET user_role= 'admin' WHERE user_id = {$the_user_id}";
$delete_user_query = mysqli_query($connection,$query);
header("location:users.php");
    
}
    
if(isset($_GET['subscriber'])){
$the_user_id = $_GET['subscriber'];
   

$query ="UPDATE users SET user_role= 'subscriber' WHERE user_id = {$the_user_id}";
$delete_user_query = mysqli_query($connection,$query);
header("location:users.php");
    
}
    


//The Delete  User query-
if(isset($_GET['delete_user'])){
$the_user_id = $_GET['delete_user'];
   

$query ="DELETE FROM users WHERE user_id = {$the_user_id}";
$delete_user_query = mysqli_query($connection,$query);
header("location:users.php");
    
}
    
?>

</div>
                        