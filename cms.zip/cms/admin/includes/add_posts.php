<?php
if(isset($_POST['create_post'])){

        
        $post_author=$_POST['author'];
        $post_title=$_POST['title'];
        $post_category_id=$_POST['post_category'];
        $post_status=$_POST['post_status'];
    
        $post_image=$_FILES['image']['name'];
        $post_image_temp =$_FILES['image']['tmp_name'];
    
        $post_content=$_POST['post_content'];
        $post_tags=$_POST['post_tags'];
        
        $post_date=date('d-m-y');
//        $post_comment_count= 4;
    
    move_uploaded_file($post_image_temp,"../images/$post_image");
    
    $query = "INSERT INTO posts(post_author,post_title,post_category_id,post_status,post_image,post_content,post_tags,post_date) ";
    
    $query .=" VALUES('{$post_author}','{$post_title}','{$post_category_id}','{$post_status}','{$post_image}','{$post_content}','{$post_tags}',now())";
    
    $insert = mysqli_query($connection,$query);
    
    confirm($insert);
    
    
    
    
}


?>

<form action="" method="post" enctype="multipart/form-data">
    
    <div class="col-xs-12">
        <label for="post_title"> Post Title </label>
        <div class="form-group">
        <input class="form-control "name="title" type="text" value="" />
        </div>
    
    </div>
    
        
        <div class="col-xs-12">
        <label for="post_category"> Post Category </label>
        <div class="form-group">
        <select name="post_category" id="post_category">
 
            
            
<?php
    
$query = "SELECT * FROM categories";
$select_categories = mysqli_query($connection,$query);
            confirm($select_categories);
            
while($row=mysqli_fetch_assoc($select_categories)){
$cat_id= $row['Cat_id'];
$cat_title =$row['Cat_title'];
    echo "<option value='{$cat_id}'>{$cat_title}</option>";
}
?>
             
            </select>
          </div>
    </div>
    
        <div class="col-xs-12">
        <label for="author"> Post Author </label>
        <div class="form-group">
        <input class="form-control "name="author" type="text" value="" />
        </div>
    
    </div>
    
    
    <div class="col-xs-12">
        <label for="role"> Post Status</label>
        <div class="form-group">
            <select  name="post_status" id="">
                <option value="draft">Select Status</option>
                <option value="published">Published</option>
                <option value="draft">Draft</option>
            
            
            </select>
        
        </div>
    
    </div>
    
        <div class="form-group">
        <label for="image"> Post Image </label>
        <input name="image" type="file" />
      
    </div>
    
        <div class="col-xs-12">
        <label for="post_tags"> Post Tags </label>
        <div class="form-group">
        <input class="form-control "name="post_tags" type="text" value="" />
        </div>
    
    </div>
    
        <div class="col-xs-12">
        <label for="post_content"> Post Content </label>
        <div class="form-group">
        <textarea class="form-control" name="post_content" id="" cols="30" rows="10"></textarea>
        </div>
    
    </div>
    
    
        <div class="form-group">
        <input class="btn btn-primary" name="create_post" type="submit" value="Publish Post" />
        </div>
    
  

</form>