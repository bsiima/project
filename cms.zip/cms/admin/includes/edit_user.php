<?php

if(isset($_GET['p_id'])){
    $the_user_id = $_GET['p_id'];

}
        $query = "SELECT * FROM users WHERE user_id =$the_user_id";
        $select_user = mysqli_query($connection,$query);
        confirm($select_user);
    while($row= mysqli_fetch_assoc($select_user)){

        $user_id = $row['user_id'];
        $username =$row['username'];
        $password =$row['password'];
        $firstname = $row['user_firstname'];
        $lastname = $row['user_lastname'];
        $email = $row['user_email'];
        $image = $row['user_image'];
        $role = $row['user_role'];
        $date = $row['randSalt'];

    }
    
    if(isset($_POST['edit_user'])){
        
             
        $username =$_POST['username'];
        $password =$_POST['password'];
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
       
        $role = $_POST['role'];
        $image=$_FILES['image']['name'];
        $image_temp =$_FILES['image']['tmp_name'];
    
        
    
    move_uploaded_file($image_temp,"../images/$image");
        if(empty($image)){
            $query ="SELECT * from users where user_id = {$the_user_id}";
            $select_user = mysqli_query($connection,$query);
            
            while($row = mysqli_fetch_assoc($select_user)){
               $image= $row['user_image']; 
            }
            
            
        }
    
        $query ="UPDATE users SET ";
        $query .="username='{$username}', ";
        $query .="user_firstname='{$firstname}', ";
        $query .="user_lastname='{$lastname}', ";
        $query .="user_email='{$email}', ";
        $query .="user_image='{$image}', ";
        $query .="user_role='{$role}', ";
        $query .="randSalt=now() ";
        $query .="WHERE user_id = {$the_user_id}";
    
    $edit_user = mysqli_query($connection,$query);
    
    confirm($edit_user);


    }
?>



<form action="" method="post" enctype="multipart/form-data">
    
    <div class="col-xs-12">
        <label for="username"> Username </label>
        <div class="form-group">
        <input class="form-control "name="username" type="text" value="<?php echo $username; ?>" />
        </div>
    
    </div>
    
        
        <div class="col-xs-12">
        <label for="password">Password </label>
        <div class="form-group">
        <input class="form-control "name="password" type="text" value="<?php echo $password; ?>" />
          </div>
    </div>
    
        <div class="col-xs-12">
        <label for="firstname"> Firstname </label>
        <div class="form-group">
        <input class="form-control "name="firstname" type="text" value="<?php echo $firstname; ?>" />
        </div>
    
    </div>
    
        <div class="col-xs-12">
        <label for="lastname"> Lastname</label>
        <div class="form-group">
        <input class="form-control "name="lastname" type="text" value="<?php echo $lastname; ?>" />
        </div>
    
    </div>
    
     <div class="col-xs-12">
        <label for="email"> Email</label>
        <div class="form-group">
        <input class="form-control "name="email" type="text" value="<?php echo $email; ?>" />
        </div>
    
    </div>
    
        <div class="form-group">
        <label for="image"> Post Image </label>
        <input name="image" type="file" value="<?php echo $image; ?>"/>
      
    </div>
    
        <div class="col-xs-12">
        <label for="role"> Role </label>
        <div class="form-group">
            <select name="role" id="">
                <option value="subscriber"><?php echo $role; ?></option> 
                <?php
                if($role == 'admin'){
                echo "<option value='subscriber'>subscriber</option>";
                }else{
                echo "<option value='admin'>admin</option>";
                
                }?>
            
            </select>
        
        </div>
    
    </div>
    
    
    
        <div class="form-group">
        <input class="btn btn-primary" name="edit_user" type="submit" value="Edit User" />
        </div>
    
  

</form>