
<?php
function confirm($result){
    global $connection;
    if(!$result){
        die("QUERY FAILED!  ". mysqli_error($connection));
    }
    
}


function insert_categories(){
                              if(isset($_POST['submit'])){
                                  global $connection;
                                  
                                  $cat_title= $_POST['cat_title'];
                                  global $connection;
                                  if ($cat_title ==""||empty($cat_title )){
                                      
                                      echo "this field cant be left empty";
                                  }else{
                                      $query = "INSERT INTO categories (Cat_title) VALUES ('{$cat_title}') ";
                                   $create_category = mysqli_query($connection,$query);  
                                      if(!$create_category){
                                          die("QUERY FAILED" . mysqli_error($connection));
                                      }
                             
                                  
                                  }
                                  
                              }
                              
}


function delete_category(){
    global $connection;
    
    if(isset($_GET['delete'])){
    $cat_id =$_GET['delete'];

    $query= "DELETE FROM categories WHERE (Cat_id) = {$cat_id}";
    $delete_category=mysqli_query($connection,$query);
    header('location:categories.php');

}

    
}


function Display_All_Categories(){
    global $connection;
    
    
                            $query = "SELECT * FROM categories ";
                            $select_query = mysqli_query($connection,$query);
                            
                            
                           while($row = mysqli_fetch_assoc($select_query)){
                                $cat_id = $row['Cat_id'];
                                $cat_title=$row['Cat_title'];
                       
                            
                                    echo "<tr>";
                                    echo "<td> {$cat_id} </td>";
                                    echo "<td> {$cat_title} </td>";   
                                    echo "<td>";
                                    echo "<a href='categories.php?delete={$cat_id}'>Delete</a> </td>";
                                    echo "<td><a href='categories.php?edit={$cat_id}'>Edit</a> </td>";
                                       
                                        echo"</tr>";
                                    }
    
}
                           


?>